// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/FoldableTheme/widgets/HeaderController/setting/nls/strings":{group:"Nume",openAll:"Deschidere toate \u00eentr-un singur panou",dropDown:"Afi\u015fare \u00een meniu derulant",noGroup:"Nu este setat niciun grup de widgeturi.",groupSetLabel:"Setare propriet\u0103\u0163i pentru grupuri de widgeturi",_localized:{}}});